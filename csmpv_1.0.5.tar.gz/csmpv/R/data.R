#' This is an example data in csmpv
#'
#' This dataset contains sample data for csmpv.
#'
#' @format A list with training and a validation datasets.
#' @author Aixiang Jiang
"datlist"